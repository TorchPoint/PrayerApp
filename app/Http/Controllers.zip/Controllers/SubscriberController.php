<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Subscriber;
use App\Http\Requests\SubscribeRequest;
use Auth;

class SubscriberController extends Controller
{
    //


    public function create(SubscribeRequest $request){
    $user=Auth::user();
    if($request->type=='monthly'){
    $end_time=strtotime("+1 month");
    $start_time=strtotime(date('Y-m-d H:i:s'));
    }else{
    $end_time=strtotime("+1 year");
    $start_time=strtotime(date('Y-m-d H:i:s'));
    }
    $request->request->add(['end_time'=>$end_time]);
    $request->request->add(['start_time'=>$start_time]);
    $request->request->add(['user_id'=>$user->id]);
    $subscribe=Subscriber::create($request->all());
    return response()->json(['status'=>1,'data'=>$subscribe]);
        


    }
    public function noti(){
   
        $SERVER_API_KEY = 'AAAA4hmacCU:APA91bF3gvxT_u93lzyWq9e6tSPy9zUII_cyaiQt4oc-SH8qoAQ6nScBqcNS-nZ3NJzFRJKNPvlGWNPsd4F5V1Izv5klo5_Q9LOlNu8mmZS0f_7AqxQ9qGRlKhuwJuvmC1Yjajv-rJAW';
        $data = [
            "to" => 'cOs4KKBQRQCZvzUx-V8EWv:APA91bH61qkWP0_Jx-8VVAECdADPRSL4mEs4EdL5mocgomtI9uk6eC4ViqRhQP3-kEEBXeOxSBVDpC_7Rpr85OKJuWqp85ko20dzRzQ_eE5C-elUOffl0Mw_EZ8o_D0du0PjBBDuT01V',
            "notification" => [
                "title" => "Group",
                "body" =>"check"
            ],
            "data"=>[
                "type"=>"group"]
        ];
        $dataString = json_encode($data);
    
        $headers = [
            'Authorization: key=' . $SERVER_API_KEY,
            'Content-Type: application/json',
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);
        $response = curl_exec($ch);
        return $response;
    }
}
