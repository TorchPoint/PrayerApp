<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reminder;
use Validator;
use Auth;
class ReminderController extends Controller
{
    //
     public function create_reminder(Request $request){
        $controls=$request->all();
        $rules=array(
        "title"=>"required",
        "reminder_date"=>"required|date",
        "type"=>"required|in:monthly,weekly,daily,once",
        'reminder_time'=>'required'
        );
        $customMessages = [
        'required' => 'The :attribute field is required.',
        'in' => 'The :attribute field is must monthly,weekly,daily or once',
        ];
        $validator=Validator::make($controls,$rules,$customMessages);
        if ($validator->fails()){
        return response()->json(['status'=>0,'message'=>$validator->errors()->all()[0]]);
        }
        $user=Auth::user();
        $reminder=new Reminder;
        $reminder->user_id=$user->id;
        $reminder->title=$request->title;
        $reminder->reminder_date=$request->reminder_date;
        $reminder->reminder_time=$request->reminder_time;
        $reminder->type=$request->type;
        $reminder->save();
        if ($reminder->save()) {
        return response()->json(['status'=>1,'date'=>$reminder]);
        }else{
        return response()->json(['status'=>0,'message'=>"Something Went Wrong...!"]); 
        }
     }


      public function update_reminder(Request $request){
        $controls=$request->all();
        $rules=array(
         "reminder"=>"required|exists:reminders,id",
        "title"=>"required",
        "reminder_date"=>"required|date",
        "type"=>"required|in:monthly,weekly,daily,once",
        'reminder_time'=>"required"
        );
        $customMessages = [
        'required' => 'The :attribute field is required.',
        'in' => 'The :attribute field is must monthly,weekly,daily or once',
        ];
        $validator=Validator::make($controls,$rules,$customMessages);
        if ($validator->fails()){
        return response()->json(['status'=>0,'message'=>$validator->errors()->all()[0]]);
        }
        $reminder= Reminder::find($request->reminder);
        $reminder->title=$request->title;
        $reminder->reminder_date=$request->reminder_date;
        $reminder->type=$request->type;
        $reminder->reminder_time=$request->reminder_time;
        $reminder->save();
        if ($reminder->save()) {
        return response()->json(['status'=>1,'date'=>$reminder]);
        }else{
        return response()->json(['status'=>0,'message'=>"Something Went Wrong...!"]); 
        }
     }


     public function edit_reminder(Request $request){
        $controls=$request->all();
        $rules=array(
        "reminder"=>"required|exists:reminders,id",
        );
        $customMessages = [
        'required' => 'The :attribute field is required.',
        'exists' => 'The :attribute not exists',
        ];
        $validator=Validator::make($controls,$rules,$customMessages);
        if ($validator->fails()){
        return response()->json(['status'=>0,'message'=>$validator->errors()->all()[0]]);
        }
        $reminder=Reminder::find($request->reminder);
        return response()->json(['status'=>1,'data'=>$reminder]);
     }


     public function delete_reminder(Request $request){
        $controls=$request->all();
        $rules=array(
        "reminder"=>"required|exists:reminders,id",
        );
        $customMessages = [
        'required' => 'The :attribute field is required.',
        'exists' => 'The :attribute not exists',
        ];
        $validator=Validator::make($controls,$rules,$customMessages);
        if ($validator->fails()){
        return response()->json(['status'=>0,'message'=>$validator->errors()->all()[0]]);
        }
        $reminder=Reminder::find($request->reminder)->delete();
        return response()->json(['status'=>1,'message'=>"reminder Deleted"]);
     }


      public function reminders(Request $request){
        $user=Auth::user();
        $reminders=Reminder::where('user_id',"=",$user->id)->get();
        if ($reminders->count()) {
        return response()->json(['status'=>1,'data'=>$reminders]);
        }
        return response()->json(['status'=>0,'message'=>"Record Not Found"]);
     }
     
     
     
     
     public function time_zone(){
         date_default_timezone_set('Asia/Karachi');

$script_tz = date_default_timezone_get();

return date("Y-m-d h:i:s");
     }
}
